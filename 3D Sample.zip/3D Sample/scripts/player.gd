extends CharacterBody3D
## Third-person player controller with climbing.
## - Camera-relative movement, mesh turns toward movement direction
## - Climbing: hold "climb" (E) facing a wall to grab, move to shimmy,
##   jump to wall-jump, push up at the top to mantle over a ledge
## - Physics: coyote time, jump buffering, variable jump height,
##   heavier falling, pushing RigidBody3Ds
## - Visuals: sprint FOV, forward lean, squash & stretch, landing camera kick,
##   dust particles
##
## Expected scene tree (origin of the body at the feet):
##   Player (CharacterBody3D)
##   ├─ CollisionShape3D
##   ├─ MeshRoot (Node3D)
##   └─ CameraRig (Node3D)
##      └─ SpringArm3D
##         └─ Camera3D

signal stamina_changed(current: float, maximum: float)

enum State { NORMAL, CLIMB, MANTLE }

@export_group("Movement")
@export var walk_speed := 5.0
@export var run_speed := 9.0
@export var ground_acceleration := 14.0
@export var air_acceleration := 3.0
@export var jump_velocity := 5.5
@export var turn_speed := 12.0

@export_group("Jump Feel")
@export var fall_gravity_multiplier := 1.6
@export var jump_cut_multiplier := 0.5
@export var coyote_time := 0.12
@export var jump_buffer_time := 0.12

@export_group("Climbing")
@export var climb_speed := 2.5
@export var climb_sideways_speed := 2.0
@export var wall_check_distance := 0.8
@export var wall_check_height := 1.0
@export var head_check_height := 1.8
@export var wall_hug_distance := 0.45
@export var max_stamina := 6.0
@export var stamina_regen := 3.0
@export var wall_jump_horizontal := 6.0
@export var wall_jump_cooldown := 0.35
@export var mantle_duration := 0.5
@export_flags_3d_physics var climb_mask := 1

@export_group("Physics")
@export var push_force := 4.0

@export_group("Camera")
@export var mouse_sensitivity := 0.0025
@export var min_pitch_degrees := -70.0
@export var max_pitch_degrees := 25.0

@export_group("Visuals")
@export var base_fov := 75.0
@export var sprint_fov := 88.0
@export var fov_lerp_speed := 6.0
@export var lean_amount := 0.18

@onready var mesh_root: Node3D = $MeshRoot
@onready var camera_rig: Node3D = $CameraRig
@onready var spring_arm: SpringArm3D = $CameraRig/SpringArm3D
@onready var camera: Camera3D = $CameraRig/SpringArm3D/Camera3D

var _pitch := deg_to_rad(-15.0)
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)

var _state: State = State.NORMAL
var _coyote_timer := 0.0
var _jump_buffer_timer := 0.0
var _wall_cooldown := 0.0
var _wall_normal := Vector3.ZERO
var _stamina := 0.0
var _last_velocity_y := 0.0
var _cam_kick := 0.0

var _squash_tween: Tween
var _run_dust: GPUParticles3D
var _burst_dust: GPUParticles3D


func _ready() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	spring_arm.rotation.x = _pitch
	floor_snap_length = 0.3
	_stamina = max_stamina
	camera.fov = base_fov
	_ensure_input_actions()
	_run_dust = _make_dust(14, false, 0.5)
	_burst_dust = _make_dust(18, true, 0.7)


func _ensure_input_actions() -> void:
	if not InputMap.has_action("climb"):
		InputMap.add_action("climb")
		var ev := InputEventKey.new()
		ev.physical_keycode = KEY_E
		InputMap.action_add_event("climb", ev)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		var mouse_motion := event as InputEventMouseMotion
		camera_rig.rotate_y(-mouse_motion.relative.x * mouse_sensitivity)
		_pitch = clampf(
			_pitch - mouse_motion.relative.y * mouse_sensitivity,
			deg_to_rad(min_pitch_degrees),
			deg_to_rad(max_pitch_degrees)
		)
		spring_arm.rotation.x = _pitch
	elif event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	elif event is InputEventMouseButton and event.is_pressed():
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _physics_process(delta: float) -> void:
	_wall_cooldown -= delta
	match _state:
		State.NORMAL:
			_process_normal(delta)
		State.CLIMB:
			_process_climb(delta)
		State.MANTLE:
			pass # Driven by a tween.
	_update_visuals(delta)


# ---------------------------------------------------------------------------
# Normal movement
# ---------------------------------------------------------------------------

func _process_normal(delta: float) -> void:
	var on_floor := is_on_floor()

	if on_floor:
		_coyote_timer = coyote_time
		_set_stamina(minf(_stamina + stamina_regen * delta, max_stamina))
	else:
		_coyote_timer -= delta

	_jump_buffer_timer -= delta
	if Input.is_action_just_pressed("jump"):
		_jump_buffer_timer = jump_buffer_time

	# Gravity (heavier while falling for a snappier arc).
	if not on_floor:
		var g := _gravity
		if velocity.y < 0.0:
			g *= fall_gravity_multiplier
		velocity.y -= g * delta

	# Jump with coyote time + buffering.
	if _jump_buffer_timer > 0.0 and _coyote_timer > 0.0:
		velocity.y = jump_velocity
		_jump_buffer_timer = 0.0
		_coyote_timer = 0.0
		_squash(Vector3(0.85, 1.2, 0.85), 0.35)
		_emit_burst()

	# Variable jump height: release early to cut the jump short.
	if Input.is_action_just_released("jump") and velocity.y > 0.0:
		velocity.y *= jump_cut_multiplier

	# Horizontal movement.
	var input_vector := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var move_direction := _get_camera_relative_direction(input_vector)
	var speed := run_speed if Input.is_action_pressed("sprint") else walk_speed
	var target_velocity := move_direction * speed

	var acceleration := ground_acceleration if on_floor else air_acceleration
	var blend := clampf(acceleration * delta, 0.0, 1.0)
	velocity.x = lerpf(velocity.x, target_velocity.x, blend)
	velocity.z = lerpf(velocity.z, target_velocity.z, blend)

	if move_direction.length_squared() > 0.01:
		var target_yaw := atan2(move_direction.x, move_direction.z)
		mesh_root.rotation.y = lerp_angle(
			mesh_root.rotation.y, target_yaw, clampf(turn_speed * delta, 0.0, 1.0)
		)

	_last_velocity_y = velocity.y
	var was_on_floor := on_floor
	move_and_slide()
	_push_bodies(delta)

	if not was_on_floor and is_on_floor():
		_on_landed(-_last_velocity_y)

	if _wall_cooldown <= 0.0 and _stamina > 0.5 and Input.is_action_pressed("climb"):
		_try_start_climb()


func _get_camera_relative_direction(input_vector: Vector2) -> Vector3:
	var camera_basis := camera_rig.global_transform.basis
	var forward := -camera_basis.z
	var right := camera_basis.x
	forward.y = 0.0
	right.y = 0.0
	return (right * input_vector.x - forward * input_vector.y).normalized()


func _push_bodies(delta: float) -> void:
	var h_speed := _horizontal_speed()
	if h_speed < 0.5:
		return
	for i in get_slide_collision_count():
		var collision := get_slide_collision(i)
		var body := collision.get_collider() as RigidBody3D
		if body == null:
			continue
		var push_dir := -collision.get_normal()
		push_dir.y = 0.0
		if push_dir.is_zero_approx():
			continue
		body.apply_impulse(
			push_dir.normalized() * push_force * h_speed * delta * 10.0,
			collision.get_position() - body.global_position
		)


# ---------------------------------------------------------------------------
# Climbing
# ---------------------------------------------------------------------------

func _facing() -> Vector3:
	var f := mesh_root.global_transform.basis.z
	f.y = 0.0
	return f.normalized()


func _cast_wall(height: float) -> Dictionary:
	var from := global_position + Vector3.UP * height
	var to := from + _facing() * wall_check_distance
	var query := PhysicsRayQueryParameters3D.create(from, to, climb_mask, [get_rid()])
	return get_world_3d().direct_space_state.intersect_ray(query)


func _try_start_climb() -> void:
	var hit := _cast_wall(wall_check_height)
	if hit.is_empty():
		return
	var n: Vector3 = hit.normal
	if absf(n.y) > 0.35:
		return # Floor or ceiling, not a climbable wall.
	_wall_normal = Vector3(n.x, 0.0, n.z).normalized()
	_state = State.CLIMB
	velocity = Vector3.ZERO
	_squash(Vector3(1.1, 0.92, 1.1), 0.2)


func _process_climb(delta: float) -> void:
	var hit := _cast_wall(wall_check_height)
	if hit.is_empty() or not Input.is_action_pressed("climb") or _stamina <= 0.0:
		_exit_climb(wall_jump_cooldown if _stamina <= 0.0 else 0.2)
		return

	var n: Vector3 = hit.normal
	_wall_normal = Vector3(n.x, 0.0, n.z).normalized()

	# Wall jump.
	if Input.is_action_just_pressed("jump"):
		velocity = _wall_normal * wall_jump_horizontal + Vector3.UP * jump_velocity
		mesh_root.rotation.y = atan2(_wall_normal.x, _wall_normal.z)
		_exit_climb(wall_jump_cooldown)
		_squash(Vector3(0.85, 1.2, 0.85), 0.3)
		_emit_burst()
		return

	var input_vector := Input.get_vector("move_left", "move_right", "move_forward", "move_back")

	# Ledge check: chest ray hits, head ray doesn't, and the player pushes up.
	if input_vector.y < -0.3:
		var head_hit := _cast_wall(head_check_height)
		if head_hit.is_empty() and _try_mantle(hit.position):
			return

	# Move along the wall plane.
	var right := (-_wall_normal).cross(Vector3.UP)
	var move := right * input_vector.x * climb_sideways_speed
	move += Vector3.UP * (-input_vector.y) * climb_speed

	# Gently hug the wall so we never drift off it.
	var from := global_position + Vector3.UP * wall_check_height
	var hit_position: Vector3 = hit.position
	var dist: float = (hit_position - from).dot(-_wall_normal)
	var stick: Vector3 = -_wall_normal * (dist - wall_hug_distance) * 12.0

	velocity = move + stick
	mesh_root.rotation.y = lerp_angle(
		mesh_root.rotation.y, atan2(-_wall_normal.x, -_wall_normal.z), clampf(15.0 * delta, 0.0, 1.0)
	)

	_set_stamina(_stamina - delta * (0.5 + input_vector.length()))
	move_and_slide()

	# Reached the floor while moving down: drop off the wall.
	if is_on_floor() and input_vector.y > 0.3:
		_exit_climb(0.2)


func _exit_climb(cooldown: float) -> void:
	_state = State.NORMAL
	_wall_cooldown = cooldown


func _try_mantle(wall_hit_position: Vector3) -> bool:
	# Look for a standable surface just past the lip of the ledge.
	var inset := wall_hit_position - _wall_normal * 0.5
	var from := Vector3(inset.x, global_position.y + head_check_height + 0.6, inset.z)
	var to := Vector3(inset.x, global_position.y + wall_check_height * 0.5, inset.z)
	var query := PhysicsRayQueryParameters3D.create(from, to, climb_mask, [get_rid()])
	var top := get_world_3d().direct_space_state.intersect_ray(query)
	if top.is_empty() or top.normal.y < 0.7:
		return false

	_state = State.MANTLE
	velocity = Vector3.ZERO
	var start := global_position
	var target: Vector3 = top.position + Vector3.UP * 0.05
	var mid := Vector3(start.x, target.y + 0.15, start.z)

	var tween := create_tween()
	tween.tween_property(self, "global_position", mid, mantle_duration * 0.6) \
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
	tween.tween_property(self, "global_position", target, mantle_duration * 0.4) \
		.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tween.finished.connect(_on_mantle_finished)
	return true


func _on_mantle_finished() -> void:
	_state = State.NORMAL
	_wall_cooldown = 0.25
	velocity = Vector3.ZERO
	_squash(Vector3(1.15, 0.85, 1.15), 0.3)
	_emit_burst()


func _set_stamina(value: float) -> void:
	var clamped := clampf(value, 0.0, max_stamina)
	if not is_equal_approx(clamped, _stamina):
		_stamina = clamped
		stamina_changed.emit(_stamina, max_stamina)


# ---------------------------------------------------------------------------
# Visuals
# ---------------------------------------------------------------------------

func _horizontal_speed() -> float:
	return Vector2(velocity.x, velocity.z).length()


func _update_visuals(delta: float) -> void:
	var h_speed := _horizontal_speed()
	var normal_state := _state == State.NORMAL

	# Sprint FOV.
	var target_fov := base_fov
	if normal_state:
		target_fov = lerpf(
			base_fov, sprint_fov, clampf(inverse_lerp(walk_speed, run_speed, h_speed), 0.0, 1.0)
		)
	camera.fov = lerpf(camera.fov, target_fov, clampf(fov_lerp_speed * delta, 0.0, 1.0))

	# Forward lean while running.
	var target_lean := 0.0
	if normal_state:
		target_lean = (h_speed / run_speed) * lean_amount * (1.0 if is_on_floor() else 0.4)
	mesh_root.rotation.x = lerpf(mesh_root.rotation.x, target_lean, clampf(10.0 * delta, 0.0, 1.0))

	# Landing camera kick decays back to zero.
	_cam_kick = lerpf(_cam_kick, 0.0, clampf(8.0 * delta, 0.0, 1.0))
	camera.v_offset = _cam_kick

	# Dust while sprinting on the ground.
	_run_dust.emitting = normal_state and is_on_floor() and h_speed > walk_speed + 0.5


func _on_landed(impact_speed: float) -> void:
	if impact_speed < 3.0:
		return
	var strength := clampf(impact_speed / 14.0, 0.0, 1.0)
	_squash(Vector3(1.0 + 0.35 * strength, 1.0 - 0.35 * strength, 1.0 + 0.35 * strength), 0.4)
	_cam_kick = -0.25 * strength
	if impact_speed > 6.0:
		_emit_burst()


func _squash(target_scale: Vector3, duration: float) -> void:
	if _squash_tween and _squash_tween.is_valid():
		_squash_tween.kill()
	mesh_root.scale = target_scale
	_squash_tween = create_tween().set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	_squash_tween.tween_property(mesh_root, "scale", Vector3.ONE, duration)


func _emit_burst() -> void:
	_burst_dust.restart()
	_burst_dust.emitting = true


func _make_dust(amount: int, one_shot: bool, lifetime: float) -> GPUParticles3D:
	var particles := GPUParticles3D.new()
	particles.amount = amount
	particles.lifetime = lifetime
	particles.one_shot = one_shot
	particles.explosiveness = 0.9 if one_shot else 0.0
	particles.local_coords = false # Particles stay in the world as we move.
	particles.emitting = false
	particles.position = Vector3(0.0, 0.05, 0.0)

	var material := ParticleProcessMaterial.new()
	material.direction = Vector3.UP
	material.spread = 70.0
	material.initial_velocity_min = 0.6
	material.initial_velocity_max = 1.8
	material.gravity = Vector3(0.0, 0.4, 0.0)
	material.scale_min = 0.6
	material.scale_max = 1.4
	var fade := Gradient.new()
	fade.set_color(0, Color(1.0, 1.0, 1.0, 0.7))
	fade.set_color(1, Color(1.0, 1.0, 1.0, 0.0))
	var fade_texture := GradientTexture1D.new()
	fade_texture.gradient = fade
	material.color_ramp = fade_texture
	particles.process_material = material

	var mesh := SphereMesh.new()
	mesh.radius = 0.08
	mesh.height = 0.16
	var mesh_material := StandardMaterial3D.new()
	mesh_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mesh_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mesh_material.vertex_color_use_as_albedo = true
	mesh_material.albedo_color = Color(0.82, 0.76, 0.66)
	mesh.material = mesh_material
	particles.draw_pass_1 = mesh

	add_child(particles)
	return particles
