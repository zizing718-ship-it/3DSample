extends SceneTree

func _init() -> void:
	var body := VehicleBody3D.new()
	var wheel := VehicleWheel3D.new()
	for prop in ["mass", "gravity_scale", "engine_force", "brake", "steering", "center_of_mass_mode", "can_sleep"]:
		print("body.", prop, "=", body.get(prop))
	for prop in [
		"wheel_radius", "wheel_rest_length", "wheel_friction_slip", "wheel_roll_influence",
		"suspension_travel", "suspension_stiffness", "suspension_max_force",
		"damping_compression", "damping_relaxation", "use_as_traction", "use_as_steering"
	]:
		print("wheel.", prop, "=", wheel.get(prop))
	quit()
