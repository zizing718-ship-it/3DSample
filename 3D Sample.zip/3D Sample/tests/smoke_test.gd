extends Node

var frames := 0
var player: CharacterBody3D


func _ready() -> void:
	var world := load("res://scenes/world.tscn").instantiate()
	add_child(world)
	player = world.get_node("Player")
	print("start: ", player.global_position)
	Input.action_press("move_forward")


func _physics_process(_delta: float) -> void:
	frames += 1
	if frames == 60:
		print("1s forward: ", player.global_position, " floor=", player.is_on_floor())
		Input.action_release("move_forward")
		Input.action_press("move_right")
		Input.action_press("sprint")
	elif frames == 120:
		print("1s right+sprint: ", player.global_position, " floor=", player.is_on_floor())
		print("speed=", Vector2(player.velocity.x, player.velocity.z).length())
		Input.action_press("jump")
	elif frames == 150:
		print("mid jump y=", player.global_position.y, " floor=", player.is_on_floor())
		Input.action_release("jump")
	elif frames == 240:
		print("landed: ", player.global_position, " floor=", player.is_on_floor())
		get_tree().quit()
